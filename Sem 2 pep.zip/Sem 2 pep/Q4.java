public class Patterns {
    public static void main(String[] args) {

        // 1) Using WHILE loop (5x5 square)
        System.out.println("Using while loop");

        int i = 1;
        while (i <= 5) {
            int j = 1;
            while (j <= 5) {
                System.out.print("* ");
                j++;
            }
            System.out.println();
            i++;
        }

        System.out.println(); // space between figures

        // 2) Using FOR loop (triangle)
        System.out.println("Using for loop");

        for (int row = 1; row <= 5; row++) {

            // print spaces
            for (int space = 5 - row; space > 0; space--) {
                System.out.print("  ");
            }

            // print stars
            for (int star = 1; star <= row; star++) {
                System.out.print("*   ");
            }

            System.out.println();
        }
    }
}