public class CalculatorDemo {
    public static void main(String[] args) {

        Calculator cal = new Calculator();

        // (3 * 4 + 5 * 7)^2
        int part1 = cal.multiply(3, 4);   // 12
        int part2 = cal.multiply(5, 7);   // 35
        int sum1 = cal.add(part1, part2); // 47
        int result1 = cal.square(sum1);   // 2209

        // (4 + 7)^2 + (8 + 3)^2
        int sum2 = cal.add(4, 7);         // 11
        int sq1 = cal.square(sum2);       // 121

        int sum3 = cal.add(8, 3);         // 11
        int sq2 = cal.square(sum3);       // 121

        int result2 = cal.add(sq1, sq2);  // 242

        System.out.println("(3*4 + 5*7)^2 = " + result1);
        System.out.println("(4+7)^2 + (8+3)^2 = " + result2);
    }
}